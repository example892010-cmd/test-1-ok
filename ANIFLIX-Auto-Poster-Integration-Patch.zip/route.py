"""Health endpoint and authenticated bridge from the SQLite File Store Bot."""

import hmac
import logging
import re
from types import SimpleNamespace
from urllib.parse import urlparse

from aiohttp import web

from config import Config

logger = logging.getLogger(__name__)
routes = web.RouteTableDef()


@routes.get("/", allow_head=True)
async def root_route_handler(request):
    return web.json_response({"status": "ok", "service": "ANIFLIX Auto-Rename Bot"})


@routes.get("/health", allow_head=True)
async def health_route_handler(request):
    return web.json_response({"status": "healthy"})


class _BridgeMessage:
    """Minimal message adapter so the existing link-only publisher stays unchanged."""

    def __init__(self, user_id: int):
        self.from_user = SimpleNamespace(id=int(user_id))
        self.response_text = ""

    async def reply_text(self, text, **_kwargs):
        self.response_text = str(text or "")
        return None


@routes.post("/internal/file-store/batch1renamed")
async def file_store_batch1renamed_handler(request):
    expected_secret = str(getattr(Config, "FILE_STORE_BRIDGE_SECRET", "") or "")
    if not expected_secret:
        return web.json_response({"ok": False, "error": "File Store bridge is not enabled on Auto Poster."}, status=503)

    supplied = request.headers.get("Authorization", "")
    supplied = supplied[7:].strip() if supplied.lower().startswith("bearer ") else ""
    if not supplied or not hmac.compare_digest(supplied, expected_secret):
        return web.json_response({"ok": False, "error": "Unauthorized bridge request."}, status=401)

    if request.content_length is not None and request.content_length > 16_384:
        return web.json_response({"ok": False, "error": "Request is too large."}, status=413)
    try:
        payload = await request.json()
        event_id = str(payload.get("event_id") or "").strip()
        title = str(payload.get("title") or "").strip()
        season = str(payload.get("season") or "").strip()
        episode = str(payload.get("episode_range") or "").strip()
        stored_link = str(payload.get("stored_link") or "").strip()
        admin_user_id = int(payload.get("admin_user_id"))
    except (TypeError, ValueError, AttributeError):
        return web.json_response({"ok": False, "error": "Invalid bridge payload."}, status=400)

    if not re.fullmatch(r"aniflix-[a-f0-9]{64}", event_id):
        return web.json_response({"ok": False, "error": "Invalid event ID."}, status=400)
    parsed_link = urlparse(stored_link)
    if parsed_link.scheme != "https" or parsed_link.netloc.lower() != "t.me" or not parsed_link.query:
        return web.json_response({"ok": False, "error": "Invalid File Store batch link."}, status=400)
    if not title or not season.isdigit() or not re.fullmatch(r"\d{1,6}(?:-\d{1,6})?", episode):
        return web.json_response({"ok": False, "error": "Invalid anime, season or episode details."}, status=400)

    client = request.app.get("telegram_client")
    if client is None:
        return web.json_response({"ok": False, "error": "Auto Poster Telegram client is not ready."}, status=503)

    from helper.database import codeflixbots
    from plugins.file_rename import _is_batch_admin, _publish_batch1renamed_link

    if not _is_batch_admin(admin_user_id):
        return web.json_response({"ok": False, "error": "The File Store owner is not an Auto Poster owner/admin."}, status=403)

    events = codeflixbots.codeflixbots["file_store_bridge_events"]
    existing = await events.find_one({"_id": event_id})
    if existing:
        state = str(existing.get("status") or "processing")
        cached = str(existing.get("response") or "")
        if state in {"completed", "completed_with_warnings"}:
            return web.json_response({"ok": True, "duplicate": True, "warnings": state == "completed_with_warnings", "response": cached})
        # A previous request claimed this event before publishing. Do not repeat sends
        # if the process was interrupted after a Telegram destination accepted a post.
        return web.json_response({"ok": True, "duplicate": True, "warnings": True, "response": cached or "This episode is already being processed or needs admin review; duplicate sending was blocked."}, status=202)

    event_record = {
        "_id": event_id,
        "status": "processing",
        "title": title,
        "season": season,
        "episode": episode,
        "stored_link": stored_link,
        "admin_user_id": admin_user_id,
    }
    try:
        await events.insert_one(event_record)
    except Exception:
        # Resolve a concurrent duplicate insert without running the publisher twice.
        existing = await events.find_one({"_id": event_id})
        if existing:
            return web.json_response({"ok": True, "duplicate": True, "warnings": True, "response": str(existing.get("response") or "Duplicate event was already claimed.")}, status=202)
        logger.exception("Could not reserve File Store bridge event %s", event_id)
        return web.json_response({"ok": False, "error": "Could not reserve publishing event."}, status=503)

    message_adapter = _BridgeMessage(admin_user_id)
    details = {
        "title": title,
        "season": season,
        "episode_range": episode,
        "stored_link": stored_link,
        "link_only": True,
        "skip_rename": True,
    }
    try:
        # This is the same existing /batch1renamed link-only publishing function.
        # Its channel, template, button, poster and FSUB behavior is not rewritten here.
        await _publish_batch1renamed_link(client, message_adapter, details)
        response_text = message_adapter.response_text or "Auto Poster completed the link-only publishing attempt."
        warnings = "❌" in response_text or "not confirmed" in response_text.lower()
        final_state = "completed_with_warnings" if warnings else "completed"
        await events.update_one(
            {"_id": event_id},
            {"$set": {"status": final_state, "response": response_text}},
        )
        return web.json_response({"ok": True, "warnings": warnings, "response": response_text})
    except Exception as exc:
        logger.exception("File Store bridge publishing failed for %s", event_id)
        error_text = f"{type(exc).__name__}: {exc}"[:1000]
        await events.update_one(
            {"_id": event_id},
            {"$set": {"status": "failed_needs_review", "response": error_text}},
        )
        return web.json_response({"ok": False, "error": error_text}, status=500)


async def web_server(client=None):
    app = web.Application(client_max_size=16_384)
    app["telegram_client"] = client
    app.add_routes(routes)
    return app
