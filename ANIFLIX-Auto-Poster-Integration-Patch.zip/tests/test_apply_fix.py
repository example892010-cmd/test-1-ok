import ast
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ReadOnlyFixVerificationTests(unittest.TestCase):
    def test_apply_fix_is_a_read_only_source_verifier(self):
        source = (ROOT / "apply_fix.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        function_names = {node.name for node in tree.body if isinstance(node, ast.FunctionDef)}
        self.assertIn("verify", function_names)
        self.assertIn("main", function_names)
        self.assertNotIn("transform_file_rename", function_names)
        self.assertNotIn("transform_ongoing_posts", function_names)

    def test_existing_link_only_publisher_and_ongoing_template_verify(self):
        result = subprocess.run(
            [sys.executable, str(ROOT / "apply_fix.py"), "--check"],
            cwd=ROOT, capture_output=True, text=True, timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("dual publishing is present", result.stdout)


if __name__ == "__main__":
    unittest.main()
