import json
import sys
import types
import unittest
from unittest.mock import patch

import route


class FakeCollection:
    def __init__(self):
        self.rows = {}

    async def find_one(self, query):
        return self.rows.get(query.get("_id"))

    async def insert_one(self, document):
        key = document["_id"]
        if key in self.rows:
            raise RuntimeError("duplicate key")
        self.rows[key] = dict(document)

    async def update_one(self, query, update):
        row = self.rows.get(query.get("_id"))
        if row:
            row.update(update.get("$set", {}))


class FakeDatabase:
    def __init__(self, collection):
        self.collection = collection

    def __getitem__(self, name):
        if name != "file_store_bridge_events":
            raise AssertionError(f"Unexpected collection: {name}")
        return self.collection


class FakeRequest:
    def __init__(self, payload, secret="shared-secret"):
        self._payload = payload
        self.headers = {"Authorization": f"Bearer {secret}"}
        self.content_length = 500
        self.app = {"telegram_client": object()}

    async def json(self):
        return self._payload


class FileStoreBridgeRuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def test_authenticated_request_calls_existing_publisher_once_and_deduplicates(self):
        calls = []
        collection = FakeCollection()

        async def publish(client, message, details):
            calls.append((client, details))
            await message.reply_text("✅ Anime Post and Ongoing attempt complete.")

        database_module = types.ModuleType("helper.database")
        database_module.codeflixbots = types.SimpleNamespace(
            codeflixbots=FakeDatabase(collection)
        )
        publisher_module = types.ModuleType("plugins.file_rename")
        publisher_module._is_batch_admin = lambda user_id: int(user_id) == 123456
        publisher_module._publish_batch1renamed_link = publish
        payload = {
            "event_id": "aniflix-" + "a" * 64,
            "title": "NARUTO SHIPPUDEN",
            "season": "18",
            "episode_range": "01",
            "stored_link": "https://t.me/ANIFLIX_FILE_STORE_BOT?start=batch_test",
            "admin_user_id": 123456,
        }
        original_secret = route.Config.FILE_STORE_BRIDGE_SECRET
        route.Config.FILE_STORE_BRIDGE_SECRET = "shared-secret"
        try:
            with patch.dict(sys.modules, {
                "helper.database": database_module,
                "plugins.file_rename": publisher_module,
            }):
                first = await route.file_store_batch1renamed_handler(FakeRequest(payload))
                self.assertEqual(first.status, 200)
                first_body = json.loads(first.text)
                self.assertTrue(first_body["ok"])
                self.assertIn("✅", first_body["response"])
                self.assertEqual(len(calls), 1)
                self.assertTrue(calls[0][1]["link_only"])
                self.assertEqual(calls[0][1]["episode_range"], "01")

                second = await route.file_store_batch1renamed_handler(FakeRequest(payload))
                second_body = json.loads(second.text)
                self.assertTrue(second_body["duplicate"])
                self.assertEqual(len(calls), 1)
        finally:
            route.Config.FILE_STORE_BRIDGE_SECRET = original_secret

    async def test_wrong_shared_secret_is_rejected_before_dispatch(self):
        original_secret = route.Config.FILE_STORE_BRIDGE_SECRET
        route.Config.FILE_STORE_BRIDGE_SECRET = "shared-secret"
        try:
            response = await route.file_store_batch1renamed_handler(
                FakeRequest({}, secret="wrong-secret")
            )
            self.assertEqual(response.status, 401)
            self.assertEqual(json.loads(response.text)["error"], "Unauthorized bridge request.")
        finally:
            route.Config.FILE_STORE_BRIDGE_SECRET = original_secret


if __name__ == "__main__":
    unittest.main()
