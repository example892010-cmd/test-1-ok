import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class FileStoreBridgeContractTests(unittest.TestCase):
    def test_internal_route_is_authenticated_and_deduplicated(self):
        source = (ROOT / "route.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        handler = next(
            node for node in tree.body
            if isinstance(node, ast.AsyncFunctionDef) and node.name == "file_store_batch1renamed_handler"
        )
        body = ast.get_source_segment(source, handler)
        self.assertIn("hmac.compare_digest", body)
        self.assertIn('codeflixbots.codeflixbots["file_store_bridge_events"]', body)
        self.assertIn("_publish_batch1renamed_link", body)
        self.assertIn('"status": "processing"', body)
        self.assertIn("duplicate", body)

    def test_bridge_calls_existing_link_only_publisher_without_media_processing(self):
        source = (ROOT / "route.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        handler = next(
            node for node in tree.body
            if isinstance(node, ast.AsyncFunctionDef) and node.name == "file_store_batch1renamed_handler"
        )
        body = ast.get_source_segment(source, handler)
        self.assertIn("await _publish_batch1renamed_link(client, message_adapter, details)", body)
        self.assertNotIn("download_media(", body)
        self.assertNotIn("auto_rename_files(", body)
        self.assertNotIn("store_file_and_process(", body)

    def test_existing_publish_function_was_not_modified(self):
        # The bridge invokes the existing command function; its plugin file is not edited.
        source = (ROOT / "plugins" / "file_rename.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        handler = next(
            node for node in tree.body
            if isinstance(node, ast.AsyncFunctionDef) and node.name == "_publish_batch1renamed_link"
        )
        body = ast.get_source_segment(source, handler)
        self.assertIn("await _post_ongoing_anime(", body)
        self.assertIn("Anime Post:", body)
        self.assertIn("Ongoing:", body)

    def test_health_server_receives_autoposter_client(self):
        source = (ROOT / "bot.py").read_text(encoding="utf-8")
        self.assertIn("web_server(self)", source)


if __name__ == "__main__":
    unittest.main()
