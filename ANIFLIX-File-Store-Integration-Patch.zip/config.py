"""Environment-backed settings for ANIFLIX FILE STORE BOT."""
from __future__ import annotations

from dataclasses import dataclass
import os
from urllib.parse import urlparse


@dataclass(frozen=True)
class Settings:
    bot_token: str
    api_id: int
    api_hash: str
    owner_id: int
    archive_channel_id: int
    admins: tuple[int, ...]
    port: int = 10000
    protect_content: bool = True
    bot_display_name: str = "ANIFLIX FILE STORE BOT"
    owner_credit: str = "@TANJIROKAMADO404"
    developer_credit: str = "@TANJIROKAMADO404"
    updates_url: str = "https://t.me/+1CcAFHLS2tU4YWVl"
    ongoing_url: str = "https://t.me/+1CcAFHLS2tU4YWVl"
    support_url: str = "https://t.me/+1jDuhUQ41hA1YmVl"
    session_name: str = "aniflix_file_store"
    batch_user_session_string: str | None = None
    sqlite_path: str = "data/aniflix.sqlite3"
    upload_channel_id: int | None = None
    auto_poster_bridge_url: str | None = None
    auto_poster_bridge_secret: str | None = None


def _required(env: dict[str, str], name: str, alias: str | None = None) -> str:
    value = env.get(name, "").strip()
    if not value and alias:
        value = env.get(alias, "").strip()
    if not value:
        raise ValueError(f"Missing required environment variable: {name}")
    return value


def _integer(value: str, name: str) -> int:
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be an integer") from exc


def _https_or_empty(env: dict[str, str], name: str, default: str) -> str:
    value = env.get(name, default).strip()
    if value and urlparse(value).scheme != "https":
        raise ValueError(f"{name} must be an HTTPS URL")
    return value


def load_settings(source: dict[str, str] | None = None) -> Settings:
    env = dict(os.environ if source is None else source)
    token = _required(env, "BOT_TOKEN", "TOKEN")
    if ":" not in token:
        raise ValueError("BOT_TOKEN does not look like a Telegram bot token")

    api_id = _integer(_required(env, "API_ID"), "API_ID")
    owner_id = _integer(_required(env, "OWNER_ID"), "OWNER_ID")
    # DB_CHANNEL is retained as the environment name for compatibility with
    # the original setup; it is a Telegram channel ID, not a database.
    archive_raw = env.get("ARCHIVE_CHANNEL_ID", "").strip() or _required(env, "DB_CHANNEL")
    archive_channel_id = _integer(archive_raw, "DB_CHANNEL/ARCHIVE_CHANNEL_ID")
    if api_id <= 0 or owner_id <= 0:
        raise ValueError("API_ID and OWNER_ID must be positive integers")
    port = _integer(env.get("PORT", "10000"), "PORT")
    if not 0 < port < 65536:
        raise ValueError("PORT must be between 1 and 65535")
    if archive_channel_id >= 0 or not str(archive_channel_id).startswith("-100"):
        raise ValueError("DB_CHANNEL must be a Telegram channel ID beginning with -100")

    upload_raw = env.get("UPLOAD_CHANNEL_ID", "").strip()
    upload_channel_id = _integer(upload_raw, "UPLOAD_CHANNEL_ID") if upload_raw else None
    if upload_channel_id is not None and (
        upload_channel_id >= 0 or not str(upload_channel_id).startswith("-100")
    ):
        raise ValueError("UPLOAD_CHANNEL_ID must be a Telegram channel ID beginning with -100")

    bridge_url = env.get("AUTO_POSTER_BRIDGE_URL", "").strip() or None
    if bridge_url and urlparse(bridge_url).scheme != "https":
        raise ValueError("AUTO_POSTER_BRIDGE_URL must be an HTTPS URL")
    bridge_secret = env.get("AUTO_POSTER_BRIDGE_SECRET", "").strip() or None

    admins = {owner_id}
    for item in env.get("ADMINS", "").replace(";", ",").split(","):
        item = item.strip()
        if item:
            admin_id = _integer(item, "ADMINS entry")
            if admin_id > 0:
                admins.add(admin_id)

    return Settings(
        bot_token=token,
        api_id=api_id,
        api_hash=_required(env, "API_HASH"),
        owner_id=owner_id,
        archive_channel_id=archive_channel_id,
        admins=tuple(sorted(admins)),
        port=port,
        # Always allow recipients to forward/save files delivered by the bot.
        # PROTECT_CONTENT is intentionally ignored, even if an old deployment
        # still has it set to true.
        protect_content=False,
        bot_display_name=env.get("BOT_DISPLAY_NAME", "ANIFLIX FILE STORE BOT").strip() or "ANIFLIX FILE STORE BOT",
        owner_credit=env.get("OWNER_CREDIT", "@TANJIROKAMADO404").strip(),
        developer_credit=env.get("DEVELOPER_CREDIT", "@TANJIROKAMADO404").strip(),
        updates_url=_https_or_empty(env, "UPDATES_URL", "https://t.me/+1CcAFHLS2tU4YWVl"),
        ongoing_url=_https_or_empty(env, "ONGOING_URL", "https://t.me/+1CcAFHLS2tU4YWVl"),
        support_url=_https_or_empty(env, "SUPPORT_URL", "https://t.me/+1jDuhUQ41hA1YmVl"),
        session_name=env.get("SESSION_NAME", "aniflix_file_store").strip() or "aniflix_file_store",
        batch_user_session_string=env.get("BATCH_USER_SESSION_STRING", "").strip() or None,
        sqlite_path=env.get("SQLITE_PATH", "data/aniflix.sqlite3").strip() or "data/aniflix.sqlite3",
        upload_channel_id=upload_channel_id,
        auto_poster_bridge_url=bridge_url,
        auto_poster_bridge_secret=bridge_secret,
    )
