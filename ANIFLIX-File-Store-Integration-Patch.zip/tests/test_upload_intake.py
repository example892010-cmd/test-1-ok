import os
import tempfile
import unittest

from helper.sqlite_store import SQLiteStore, SCHEMA_VERSION


class UploadIntakeSQLiteTests(unittest.TestCase):
    def test_new_tables_are_additive_and_batch_candidates_can_be_claimed(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "aniflix.sqlite3")
            db = SQLiteStore(path)
            self.assertEqual(db._connection.execute("PRAGMA user_version").fetchone()[0], SCHEMA_VERSION)
            for message_id, quality in ((20, "1080p"), (18, "480p"), (19, "720p")):
                db.record_upload_candidate(
                    upload_chat_id=-1001234567890, source_message_id=message_id,
                    quality=quality, file_unique_id=f"uniq-{message_id}", file_name=f"file-{quality}.mkv",
                    media_type="document",
                )
            candidates = db.list_pending_upload_candidates(-1001234567890, limit=4)
            self.assertEqual([row["source_message_id"] for row in candidates], [18, 19, 20])
            event_id = "aniflix-test-event"
            db.create_upload_batch(
                event_id=event_id, upload_chat_id=-1001234567890,
                source_message_ids=[18, 19, 20], anime_title="Naruto Shippuden",
                season="18", episode="365",
            )
            db.claim_upload_candidates(-1001234567890, [18, 19, 20], event_id)
            self.assertEqual(db.list_pending_upload_candidates(-1001234567890, limit=4), [])
            db.update_upload_candidate(-1001234567890, 18, status="stored", archive_message_id=501)
            db.update_upload_batch(event_id, manifest_message_id=800, batch_url="https://t.me/store?start=batch_abc", status="stored_pending_publish")
            batch = db.get_upload_batch(event_id)
            self.assertEqual(batch["manifest_message_id"], 800)
            self.assertEqual(batch["status"], "stored_pending_publish")
            db.close()

    def test_atomic_batch_claim_prevents_cross_batch_reuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = SQLiteStore(os.path.join(tmp, "aniflix.sqlite3"))
            for message_id, quality in ((10, "480p"), (11, "720p"), (12, "1080p")):
                db.record_upload_candidate(
                    upload_chat_id=-1001234567890, source_message_id=message_id,
                    quality=quality, file_unique_id=f"u-{message_id}", file_name=f"{quality}.mkv",
                    media_type="document",
                )
            db.claim_upload_candidates(-1001234567890, [10], "another-event")
            with self.assertRaisesRegex(RuntimeError, "already claimed"):
                db.create_and_claim_upload_batch(
                    event_id="new-event", upload_chat_id=-1001234567890,
                    source_message_ids=[10, 11, 12], anime_title="Naruto",
                    season="18", episode="365",
                )
            self.assertIsNone(db.get_upload_batch("new-event"))
            self.assertEqual(
                [row["source_message_id"] for row in db.list_pending_upload_candidates(-1001234567890)],
                [11, 12],
            )
            db.close()

    def test_atomic_batch_claim_commits_batch_and_all_candidates_together(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = SQLiteStore(os.path.join(tmp, "aniflix.sqlite3"))
            for message_id, quality in ((10, "480p"), (11, "720p"), (12, "1080p")):
                db.record_upload_candidate(
                    upload_chat_id=-1001234567890, source_message_id=message_id,
                    quality=quality, file_unique_id=f"u-{message_id}", file_name=f"{quality}.mkv",
                    media_type="document",
                )
            batch = db.create_and_claim_upload_batch(
                event_id="aniflix-atomic", upload_chat_id=-1001234567890,
                source_message_ids=[10, 11, 12], anime_title="Naruto",
                season="18", episode="365",
            )
            self.assertEqual(batch["status"], "processing")
            self.assertEqual(db.list_pending_upload_candidates(-1001234567890), [])
            claimed = db._connection.execute(
                "SELECT batch_event_id, status FROM upload_candidates ORDER BY source_message_id"
            ).fetchall()
            self.assertEqual([(row[0], row[1]) for row in claimed], [("aniflix-atomic", "claimed")] * 3)
            db.close()

    def test_existing_batch_event_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = SQLiteStore(os.path.join(tmp, "aniflix.sqlite3"))
            first = db.create_upload_batch(
                event_id="same", upload_chat_id=-1001, source_message_ids=[1, 2, 3],
                anime_title="Naruto", season="1", episode="1",
            )
            db.update_upload_batch("same", status="published", batch_url="https://t.me/store?start=batch_x")
            second = db.create_upload_batch(
                event_id="same", upload_chat_id=-1001, source_message_ids=[4, 5, 6],
                anime_title="Naruto", season="1", episode="1",
            )
            self.assertEqual(second["source_message_ids"], first["source_message_ids"])
            self.assertEqual(db.get_upload_batch("same")["status"], "published")
            db.close()


if __name__ == "__main__":
    unittest.main()
