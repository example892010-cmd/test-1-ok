import unittest
from types import SimpleNamespace

from helper.anime_batch_utils import detect_quality, episode_event_id, parse_batch1renamed_command


class AnimeBatchUtilsTests(unittest.TestCase):
    def test_quality_detected_from_names_in_any_order(self):
        samples = ["Naruto S18 E365 [1080p].mkv", "episode_365_480p.mp4", "ep365 720P.mkv"]
        self.assertEqual([detect_quality(name) for name in samples], ["1080p", "480p", "720p"])

    def test_quality_detected_from_video_height_when_name_has_no_label(self):
        self.assertEqual(detect_quality("Naruto.mp4", height=1080), "1080p")
        self.assertEqual(detect_quality("Naruto.mp4", height=720), "720p")
        self.assertEqual(detect_quality("Naruto.mp4", height=480), "480p")

    def test_quality_is_not_guessed_when_labels_conflict_or_are_missing(self):
        self.assertIsNone(detect_quality("Naruto 480p 1080p.mkv"))
        self.assertIsNone(detect_quality("Naruto.mkv"))
        self.assertIsNone(detect_quality("Naruto.mkv", height=300))

    def test_command_accepts_episode_number_variants(self):
        for raw, expected in (("365", "365"), ("01", "01"), ("Epi 25", "25"), ("Episode 01", "01")):
            parsed = parse_batch1renamed_command(
                f"/batch1renamed\nNARUTO SHIPPUDEN\nSeason 18\n{raw}"
            )
            self.assertEqual(parsed["title"], "NARUTO SHIPPUDEN")
            self.assertEqual(parsed["season"], "18")
            self.assertEqual(parsed["episode_range"], expected)

    def test_command_accepts_episode_ranges_and_rejects_bad_details(self):
        parsed = parse_batch1renamed_command("/batch1renamed\nNaruto Shippuden\nSeason 18\nEpi 25-26")
        self.assertEqual(parsed["episode_range"], "25-26")
        with self.assertRaises(ValueError):
            parse_batch1renamed_command("/batch1renamed\nNaruto\nSeason 18\n25-01")
        with self.assertRaises(ValueError):
            parse_batch1renamed_command("/batch1renamed\nNaruto\nSeason 18")

    def test_episode_event_id_is_stable_across_case_and_zero_padding(self):
        self.assertEqual(
            episode_event_id("NARUTO SHIPPUDEN", "018", "0365"),
            episode_event_id("Naruto Shippuden", "18", "365"),
        )


if __name__ == "__main__":
    unittest.main()
