import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class UploadHandlerIntegrationTests(unittest.TestCase):
    def test_batch1renamed_is_excluded_from_existing_private_catch_all(self):
        source = (ROOT / "bot.py").read_text(encoding="utf-8")
        self.assertIn('"batch1renamed"', source)
        self.assertIn("register_anime_batch_bridge_handlers(bot)", source)

    def test_bridge_uses_existing_file_store_and_manifest_helpers(self):
        source = (ROOT / "helper" / "anime_batch_bridge.py").read_text(encoding="utf-8")
        self.assertIn("bot.file_storage.store_message(source)", source)
        self.assertIn("save_batch_manifest(bot, bot.archive_channel_id, archive_ids)", source)
        self.assertIn("encode_batch_manifest_id", source)
        self.assertIn("AUTO_POSTER_BRIDGE_SECRET", source)

    def test_no_media_download_or_reupload_in_bridge(self):
        source = (ROOT / "helper" / "anime_batch_bridge.py").read_text(encoding="utf-8").lower()
        self.assertNotIn("download_media", source)
        self.assertNotIn("send_video", source)
        self.assertNotIn("send_document", source)


if __name__ == "__main__":
    unittest.main()
