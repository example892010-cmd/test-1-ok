"""Pure helpers for ANIFLIX's three-quality File Store -> Auto Poster intake."""
from __future__ import annotations

import hashlib
import re

QUALITY_ORDER = ("480p", "720p", "1080p")


def detect_quality(file_name: str = "", caption: str = "", *, height: int | None = None) -> str | None:
    """Identify one supported quality from a filename/caption or Telegram video height.

    The function deliberately returns None when textual labels conflict or cannot be
    found; it never guesses from upload order.
    """
    text = f"{file_name or ''} {caption or ''}"
    matches = {f"{value}p" for value in re.findall(
        r"(?<!\d)(480|720|1080)\s*p(?!\d)", text, flags=re.IGNORECASE
    )}
    if len(matches) == 1:
        return next(iter(matches))
    if len(matches) > 1:
        return None
    try:
        video_height = int(height or 0)
    except (TypeError, ValueError):
        video_height = 0
    if video_height >= 1000:
        return "1080p"
    if video_height >= 650:
        return "720p"
    if video_height >= 430:
        return "480p"
    return None


def parse_batch1renamed_command(text: str) -> dict:
    """Parse /batch1renamed + anime title + season + episode (no URL required)."""
    lines = [line.strip() for line in (text or "").splitlines() if line.strip()]
    if not lines or not re.fullmatch(r"/batch1renamed(?:@\w+)?", lines[0], re.IGNORECASE):
        raise ValueError("Use /batch1renamed followed by anime title, season and episode.")
    details = lines[1:]
    if len(details) < 3:
        raise ValueError(
            "Format:\n/batch1renamed\nNARUTO SHIPPUDEN\nSeason 18\n365"
        )
    if any(re.match(r"https?://", item, re.IGNORECASE) for item in details):
        raise ValueError("Do not add a link. The File Store Bot generates the batch link automatically.")
    title_parts = details[:-2]
    title = " ".join(title_parts).strip()
    season_match = re.fullmatch(r"(?:season\s*)?(\d{1,3})", details[-2], re.IGNORECASE)
    episode_match = re.fullmatch(
        r"(?:epi(?:sode)?\s*)?(\d{1,6})(?:\s*[-–]\s*(\d{1,6}))?",
        details[-1], re.IGNORECASE,
    )
    if not title or not season_match or not episode_match:
        raise ValueError(
            "Could not read the details. Use:\n/batch1renamed\nNARUTO SHIPPUDEN\nSeason 18\n365"
        )
    season = str(int(season_match.group(1)))
    # Preserve the administrator's formatting (for example, episode 01) for
    # existing caption/button templates. Idempotency normalizes numeric padding
    # separately in episode_event_id().
    first = episode_match.group(1)
    last = episode_match.group(2) if episode_match.group(2) else None
    if last and int(last) < int(first):
        raise ValueError("Episode range end must be greater than or equal to its start.")
    episode = f"{first}-{last}" if last and last != first else first
    return {"title": title, "season": season, "episode_range": episode}


def episode_event_id(title: str, season: str, episode: str) -> str:
    """Stable idempotency key for one anime/season/episode bridge publication."""
    normalized_title = re.sub(r"[^a-z0-9]+", " ", str(title or "").casefold()).strip()
    if not normalized_title:
        raise ValueError("Anime title is required")
    season_number = int(season)
    episode_match = re.fullmatch(r"(\d+)(?:-(\d+))?", str(episode).strip())
    if not episode_match:
        raise ValueError("Episode must be a number or numeric range")
    start = str(int(episode_match.group(1)))
    end = str(int(episode_match.group(2))) if episode_match.group(2) else ""
    identity = f"{normalized_title}|s{season_number}|e{start}-{end}"
    return "aniflix-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()
