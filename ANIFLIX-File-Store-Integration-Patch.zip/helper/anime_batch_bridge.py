"""Three-file upload channel intake and signed handoff to the existing Auto Poster."""
from __future__ import annotations

import asyncio
import json
import logging
from urllib.parse import urlparse

import aiohttp
from pyrogram import filters

from helper.anime_batch_utils import QUALITY_ORDER, detect_quality, episode_event_id, parse_batch1renamed_command
from helper.link_codec import encode_batch_manifest_id
from helper.storage import save_batch_manifest

logger = logging.getLogger(__name__)
_BATCH_LOCK = asyncio.Lock()


def _get_media(message):
    for field in ("video", "document"):
        media = getattr(message, field, None)
        if media:
            return media, field
    return None, ""


def _media_details(message):
    media, media_type = _get_media(message)
    if not media:
        return None
    filename = str(getattr(media, "file_name", "") or "")
    caption = str(getattr(message, "caption", "") or "")
    height = getattr(media, "height", None) if media_type == "video" else None
    quality = detect_quality(filename, caption, height=height)
    return {
        "quality": quality,
        "file_unique_id": str(getattr(media, "file_unique_id", "") or ""),
        "file_name": filename,
        "file_size": int(getattr(media, "file_size", 0) or 0),
        "media_type": media_type,
        "caption": caption,
    }


async def _reply(message, text: str, client=None):
    try:
        chat = getattr(message, "chat", None)
        chat_type = str(getattr(chat, "type", "")).lower()
        if "channel" in chat_type and client is not None:
            return await client.send_message(
                int(chat.id), text, disable_web_page_preview=True
            )
        return await message.reply_text(text, disable_web_page_preview=True)
    except Exception:
        logger.exception("Could not reply to the upload-channel integration message")
        return None


async def _post_to_auto_poster(bot, *, event_id: str, details: dict, batch_url: str, actor_id: int) -> dict:
    settings = bot.settings
    bridge_url = str(settings.auto_poster_bridge_url or "").strip()
    secret = str(settings.auto_poster_bridge_secret or "").strip()
    if not bridge_url or not secret:
        raise RuntimeError(
            "Auto Poster bridge is not configured. Set AUTO_POSTER_BRIDGE_URL and "
            "AUTO_POSTER_BRIDGE_SECRET in the File Store Bot environment."
        )
    parsed = urlparse(bridge_url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise RuntimeError("AUTO_POSTER_BRIDGE_URL must be a complete HTTPS URL.")
    payload = {
        "event_id": event_id,
        "title": details["title"],
        "season": details["season"],
        "episode_range": details["episode_range"],
        "stored_link": batch_url,
        "admin_user_id": int(actor_id),
    }
    timeout = aiohttp.ClientTimeout(total=45, connect=10, sock_read=35)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(
            bridge_url,
            json=payload,
            headers={"Authorization": f"Bearer {secret}"},
            allow_redirects=False,
        ) as response:
            try:
                result = await response.json(content_type=None)
            except Exception:
                result = {"response": (await response.text())[:500]}
            if response.status not in (200, 202):
                raise RuntimeError(
                    f"Auto Poster returned HTTP {response.status}: "
                    f"{result.get('error') or result.get('response') or 'unknown error'}"
                )
            if not result.get("ok"):
                raise RuntimeError(str(result.get("error") or "Auto Poster did not confirm the handoff"))
            return result


async def _process_batch(bot, message, text: str, actor_id: int):
    settings = bot.settings
    upload_channel_id = settings.upload_channel_id
    if not upload_channel_id:
        return await _reply(message, "❌ Upload channel is not configured. Set UPLOAD_CHANNEL_ID first.", bot)
    try:
        details = parse_batch1renamed_command(text)
        event_id = episode_event_id(details["title"], details["season"], details["episode_range"])
    except ValueError as exc:
        return await _reply(message, f"❌ {exc}", bot)

    async with _BATCH_LOCK:
        db = bot.state_store.database
        existing = db.get_upload_batch(event_id)
        if existing:
            state = str(existing.get("status") or "")
            if state == "claim_failed":
                return await _reply(message, "❌ These source uploads were already assigned to a different batch. Upload a fresh set of three qualities before retrying.", bot)
            if state in {"published", "published_with_warnings"}:
                return await _reply(
                    message,
                    "✅ This anime episode was already handed to Auto Poster. Duplicate processing was prevented.\n"
                    f"🔗 {existing.get('batch_url') or ''}",
                    bot,
                )
            if existing.get("batch_url") and state == "stored_pending_publish":
                batch_url = str(existing["batch_url"])
                try:
                    result = await _post_to_auto_poster(
                        bot, event_id=event_id, details=details, batch_url=batch_url, actor_id=actor_id
                    )
                    final_state = "published_with_warnings" if result.get("warnings") else "published"
                    response_text = str(result.get("response") or "Auto Poster accepted the batch.")
                    db.update_upload_batch(event_id, status=final_state, publish_response=response_text)
                    return await _reply(message, f"✅ Stored link handed to Auto Poster.\n🔗 {batch_url}\n\n{response_text}", bot)
                except Exception as exc:
                    logger.exception("Retrying the File Store -> Auto Poster handoff failed")
                    return await _reply(message, f"⚠️ Files are stored, but publishing handoff failed.\n🔗 {batch_url}\n\n{exc}\nSend the same command again to retry.", bot)
            try:
                source_message_ids = json.loads(existing.get("source_message_ids") or "[]")
            except (TypeError, json.JSONDecodeError):
                source_message_ids = []
            if not source_message_ids:
                return await _reply(message, "❌ A previous batch record is incomplete. Contact the administrator before retrying.", bot)
        else:
            candidates = db.list_pending_upload_candidates(upload_channel_id, limit=4)
            if len(candidates) != 3:
                return await _reply(
                    message,
                    f"📥 I found {len(candidates)} unprocessed upload(s). Exactly 3 files are required.\n"
                    "Upload the 480p, 720p and 1080p files in any order, then send the command again.",
                    bot,
                )
            by_quality = {}
            for item in candidates:
                quality = str(item.get("quality") or "")
                if quality not in QUALITY_ORDER:
                    return await _reply(
                        message,
                        f"❌ I could not identify the quality of `{item.get('file_name') or 'one file'}`.\n"
                        "Add 480p, 720p or 1080p to its filename/caption, or send it as a video with Telegram dimensions, then upload it again.",
                        bot,
                    )
                if quality in by_quality:
                    return await _reply(message, f"❌ Two files were identified as {quality}. Please correct the filenames/captions and upload the missing quality.", bot)
                by_quality[quality] = item
            if set(by_quality) != set(QUALITY_ORDER):
                missing = ", ".join(q for q in QUALITY_ORDER if q not in by_quality)
                return await _reply(message, f"❌ Missing quality: {missing}. Upload all three qualities before sending the command.", bot)
            unique_ids = [str(item.get("file_unique_id") or "") for item in by_quality.values()]
            if all(unique_ids) and len(set(unique_ids)) != 3:
                return await _reply(message, "❌ The three upload messages contain duplicate Telegram files. Upload three different quality files.", bot)
            ordered = [by_quality[q] for q in QUALITY_ORDER]
            source_message_ids = [int(item["source_message_id"]) for item in ordered]
            try:
                existing = db.create_and_claim_upload_batch(
                    event_id=event_id,
                    upload_chat_id=upload_channel_id,
                    source_message_ids=source_message_ids,
                    anime_title=details["title"],
                    season=details["season"],
                    episode=details["episode_range"],
                )
            except Exception:
                logger.exception("Could not atomically claim the staged episode files")
                return await _reply(message, "❌ These uploads are already assigned to another batch or are no longer pending. Upload a fresh set of three qualities.", bot)

        db.update_upload_batch(event_id, status="storing")
        archive_ids = []
        try:
            for quality, source_message_id in zip(QUALITY_ORDER, source_message_ids):
                source = await bot.get_messages(upload_channel_id, int(source_message_id))
                if not source or getattr(source, "empty", False):
                    raise RuntimeError(f"The original {quality} upload could not be read from the upload channel.")
                archived = await bot.file_storage.store_message(source)
                if not archived or not getattr(archived, "id", None):
                    raise RuntimeError(f"The {quality} file could not be verified in the File Store archive channel.")
                archive_id = int(archived.id)
                archive_ids.append(archive_id)
                db.update_upload_candidate(
                    upload_channel_id, int(source_message_id), status="stored", archive_message_id=archive_id,
                )

            batch_record = db.get_upload_batch(event_id) or {}
            manifest_message_id = batch_record.get("manifest_message_id")
            if not manifest_message_id:
                manifest_message_id = await save_batch_manifest(bot, bot.archive_channel_id, archive_ids)
                db.update_upload_batch(event_id, manifest_message_id=int(manifest_message_id))
            payload = "batch_" + encode_batch_manifest_id(int(manifest_message_id))
            db.record_link(payload, "batch_manifest", int(manifest_message_id))
            username = str(getattr(bot, "username", "") or "").strip().lstrip("@")
            if not username:
                raise RuntimeError("File Store Bot username is unavailable; cannot create the deep link.")
            batch_url = f"https://t.me/{username}?start={payload}"
            db.update_upload_batch(event_id, batch_url=batch_url, status="stored_pending_publish")
        except Exception as exc:
            logger.exception("Could not archive the three-quality anime batch")
            db.update_upload_batch(event_id, status="storage_failed", publish_response=str(exc)[:1000])
            return await _reply(message, f"❌ File Store failed: {type(exc).__name__}: {exc}\nSend the same command again to retry; already verified archive copies will be reused.", bot)

        try:
            result = await _post_to_auto_poster(
                bot, event_id=event_id, details=details, batch_url=batch_url, actor_id=actor_id
            )
            final_state = "published_with_warnings" if result.get("warnings") else "published"
            response_text = str(result.get("response") or "Auto Poster accepted the batch.")
            db.update_upload_batch(event_id, status=final_state, publish_response=response_text)
            return await _reply(
                message,
                f"✅ Three files stored and batch link generated.\n"
                f"🎬 {details['title']} • Season {details['season']} • Episode {details['episode_range']}\n"
                f"🔗 {batch_url}\n\n{response_text}",
                bot,
            )
        except Exception as exc:
            logger.exception("File Store succeeded but Auto Poster handoff failed")
            db.update_upload_batch(event_id, status="stored_pending_publish", publish_response=str(exc)[:1000])
            return await _reply(
                message,
                f"⚠️ The 3 files are safely stored and the batch link was generated, but Auto Poster did not confirm publishing.\n"
                f"🔗 {batch_url}\n\n{type(exc).__name__}: {exc}\n"
                "Send the same /batch1renamed command again to retry the handoff.",
                bot,
            )


def register_handlers(client):
    """Register additive upload-channel handlers; existing File Store handlers remain intact."""

    @client.on_message(filters.channel, group=-20)
    async def upload_channel_listener(_client, message):
        if not client.settings.upload_channel_id or int(message.chat.id) != int(client.settings.upload_channel_id):
            return
        text = str(getattr(message, "text", "") or "").strip()
        if text and text.splitlines()[0].split("@", 1)[0].lower() == "/batch1renamed":
            return await _process_batch(client, message, text, client.settings.owner_id)
        details = _media_details(message)
        if not details:
            return
        if not details["quality"]:
            return await _reply(
                message,
                "⚠️ I received the file but could not identify 480p, 720p or 1080p. Add its quality to the filename/caption, or send it as a video with Telegram dimensions, then upload it again.",
                client,
            )
        client.state_store.database.record_upload_candidate(
            upload_chat_id=int(message.chat.id),
            source_message_id=int(message.id),
            quality=details["quality"],
            file_unique_id=details["file_unique_id"],
            file_name=details["file_name"],
            file_size=details["file_size"],
            media_type=details["media_type"],
            caption=details["caption"],
        )
        pending = client.state_store.database.list_pending_upload_candidates(
            int(message.chat.id), limit=20
        )
        label = details["quality"] or "quality not identified"
        await _reply(message, f"📥 Received {label}. Unprocessed uploads: {len(pending)}.\nUpload 480p, 720p and 1080p in any order, then send /batch1renamed with the anime details.", client)

    @client.on_message(filters.private & filters.command("batch1renamed"), group=-20)
    async def private_batch_command(_client, message):
        user = getattr(message, "from_user", None)
        if not user or int(user.id) not in set(client.settings.admins):
            return await _reply(message, "⛔ Admin only.", client)
        return await _process_batch(client, message, message.text or "", int(user.id))

    return True
